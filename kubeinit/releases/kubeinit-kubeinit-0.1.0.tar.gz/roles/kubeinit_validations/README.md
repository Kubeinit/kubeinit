# kubeinit_validations

Check the role kubeinit_validations [official docs](https://kubeinit.github.io/kubeinit/roles/role-kubeinit_validations.html)
for further information.
