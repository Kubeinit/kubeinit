# kubeinit_kubevirt

Check the role kubeinit_kubevirt [official docs](https://kubeinit.github.io/kubeinit/roles/role-kubeinit_kubevirt.html)
for further information.
