# okd

Check the role [official docs](https://kubeinit.github.io/kubeinit/)
for further information.
